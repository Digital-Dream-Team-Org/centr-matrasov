Simple gulp bundler for static web page building
Gulp version - 4
